
<?php 
require_once("header.php");
require("admin/connection.php");

if(isset($_GET['cat']))
{
	$cat = $_GET['cat'];
	$query = "select * from news where category = '$cat'";
	$run = mysqli_query($con,$query) or die(mysqli_error($con));
	if($run)
	{
		while($data=mysqli_fetch_assoc($run))
		{
			?>
			
			<div class="wthree-top-1">
					<div class="w3agile-top">
						<img src="admin/assets/images/<?= $data['image']?>" width="600">

						<div class="w3agile-middle">
						<ul>
							<li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>FEB 15,2017</a></li>
							<li><a href="#"><i class="fa fa-thumbs-up" aria-hidden="true"></i>201 LIKES</a></li>
							<li><a href="#"><i class="fa fa-comment" aria-hidden="true"></i>15 COMMENTS</a></li>
							
						</ul>
					</div>
					</div>
					
					<div class="w3agile-bottom">
						<div class="col-md-3 w3agile-left">
							<h5></h5>
						</div>
						<div class="col-md-9 w3agile-right">
							<h3><a href="singlepage.html"><?= $data['title'];?></a></h3>
							<p><?= $data['news'];?></p>
							<a class="agileits w3layouts" href="singlepage.html">Read More <span class="glyphicon agileits w3layouts glyphicon-arrow-right" aria-hidden="true"></span></a>
						</div>
							<div class="clearfix"></div>
					</div>
				</div>
			
			<?php
		}
	}
}

require_once("footer.php");
 ?>
