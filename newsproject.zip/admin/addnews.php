<?php 
require("connection.php");
if(isset($_POST['sub']))
{
	$cat = $_POST['cat'];
	$title = $_POST['title'];
	$news = mysqli_real_escape_string($con,$_POST['news']);#sql injection

	$image = $_FILES['image']['name'];
	$tmp_name = $_FILES['image']['tmp_name'];
	$exp = explode('.',$image);
	$ext = strtolower(end($exp));
	$new_image = rand().'.'.$ext;
	$path = "assets/images/".$new_image;

	if($ext == 'jpg' ||$ext == 'png' ||$ext == 'jpeg')
	{
		if(move_uploaded_file($tmp_name, $path))
		{
			$query= "insert into news(title,image,category,news) values ('$title','$new_image','$cat','$news')";
			$run = mysqli_query($con,$query) or die(mysqli_error($con));
			if($run)
			{
				header("location:home.php?page=news");
			}	
		}
		
	}
	else
	{
		echo "choose only jpg jpeg and png files only";
	}
	
	

}

 ?>
<h1><center style="color:green">Add news</center></h1>
<form method="post" action="" enctype="multipart/form-data">
	<select class="form-control" name="cat">
		<option hidden>Choose category</option>
		<?php 
		require("connection.php");
		$query="select * from category";
		$run = mysqli_query($con,$query) or die(mysqli_error($con));
		if($run)
		{
			while($data=mysqli_fetch_assoc($run))
			{
				?>
				<option value="<?= $data['cat_name'];?>"><?= $data['cat_name'];?></option>
				<?php
			}
		}


		 ?>
	</select><br>
	<label>Title</label><br>
		<input type="text" name="title" placeholder="Enter title" class="form-control"><br>
		<label>Image</label><br>
		<input type="file" name="image"><br>
		<label>News</label><br>
		<textarea name="news" rows="6" class="form-control"></textarea><br>
		<input type="submit" name="sub" value="Add news">
</form>