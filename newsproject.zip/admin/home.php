<?php 
session_start();

if(isset($_SESSION['user_name']) && isset($_SESSION['password']))
{
	?>
<!DOCTYPE html>
<html>
<head>
	<title>admin panel</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<script type="text/javascript" src="assests/js/jquery.js"></script>
	<script src="assets/js/bootstrap.js"></script>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-12">
			<div class="jumbotron">
				<h1 style="text-align: center;color:green">Welcome:-</h1>
				<ul>
					<li style="float:right;list-style:none"><a href="logout.php"><h4>Logout</h4></li>
				</ul>
				
			</div>
		</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-3">
			<div class="jumbotron">
				<a href="home.php?page=news"><h3>News</h3></a>
				<a href="home.php?page=category"><h3>Category</h3></a>
				<a href="#"><h3>Feedback</h3></a>
				<a href="#"><h3>User</h3></a>

			</div>
			
		</div>
		<div class="col-md-9">
			<?php 
			if(isset($_GET['page']))
			{
				$page = $_GET['page'];

				switch($page)
				{
					case 'category': include('category.php');
					break;
					case 'editnews': include('editnews.php');
					break;
					case 'news':include('news.php');
					break;
					case 'addnews':include('addnews.php');
					break;
					case 'addcategory':include('addcategory.php');
					break;
				}
			}


			 ?>
		</div>
		</div>
	</div>
</body>
</html>

	<?php
}
else
{
	header("location:index.php");
}


 ?>

