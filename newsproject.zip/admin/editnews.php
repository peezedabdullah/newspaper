<?php 
require("connection.php");
//get data from database and send to form
if(isset($_GET['id']))
{
	$id = $_GET['id'];
	$query1 = "select * from news where id = '$id'";
	$run1 = mysqli_query($con,$query1) or die(mysqli_error($con));
	if($run1)
	{
		$data = mysqli_fetch_array($run1);
	} 
}
//update
if(isset($_POST['sub']))
{
	
	$title = $_POST['title'];
	$news = mysqli_real_escape_string($con,$_POST['news']);#sql injection

	$image = $_FILES['image']['name'];
	$tmp_name = $_FILES['image']['tmp_name'];
	$exp = explode('.',$image);
	$ext = strtolower(end($exp));
	$new_image = rand().'.'.$ext;
	$path = "assets/images/".$new_image;

	if($ext == 'jpg' ||$ext == 'png' ||$ext == 'jpeg')
	{
		if(move_uploaded_file($tmp_name, $path))
		{
			$query= "update news set title='$title',image = '$new_image',news = '$news' where id = '$id'";
			$run = mysqli_query($con,$query) or die(mysqli_error($con));
			if($run)
			{
				header("location:home.php?page=news");
			}	
		}
		
	}
	else
	{
		echo "choose only jpg jpeg and png files only";
	}
	
	

}

 ?>

<form method="post" action="" enctype="multipart/form-data">
	<label>Title</label><br>
		<input type="text" name="title" value="<?= $data['title'];?>" class="form-control"><br>
		<label>Image</label><br>
		<img src="assets/images/<?= $data['image'];?>" width="60">
		<input type="file" name="image"><br>
		<label>News</label><br>
		<textarea name="news" rows="6" class="form-control"><?= $data['news'];?></textarea><br>
		<input type="submit" name="sub" value="Update news">
</form>