<?php 
session_start();
require("connection.php");
if(isset($_POST['sub']))
{
	$uname = $_POST['uname'];
	$password = md5($_POST['password']);

	$query = "select * from admin_login where user_name = '$uname' and password = '$password' ";
	$run = mysqli_query($con,$query) or die(mysqli_error($con));
	$row = mysqli_num_rows($run);
	
	$data = mysqli_fetch_assoc($run);
	$user_name = $data['user_name'];
	$password = $data['password'];
	if($row == 1)
	{
		$_SESSION['user_name'] = $user_name;
		$_SESSION['password'] = $password;
		header("location:home.php");
	}
	else
	{
		echo "<h1><center style='color:red'>invalid username or password</center></h1>";
	}
}

 ?>