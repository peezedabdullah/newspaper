<?php 
$con = mysqli_connect("localhost","root","","newproject");

if(!$con)
{
	echo "database not connected";

}

 ?>