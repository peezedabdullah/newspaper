<h1>Category me hu</h1>
<a href="home.php?page=addcategory" class="btn btn-primary">Add category</a>
<select class="form-control">
		<option hidden>All category</option>
		<?php 
		require("connection.php");
		$query="select * from category";
		$run = mysqli_query($con,$query) or die(mysqli_error($con));
		if($run)
		{
			while($data=mysqli_fetch_assoc($run))
			{
				?>
				<option><?= $data['cat_name'];?></option>
				<?php
			}
		}


		 ?>
	</select>