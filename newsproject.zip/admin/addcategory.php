<?php 
require("connection.php");
if(isset($_POST['sub']))
{
	$cat = $_POST['cat'];

	$query= "insert into category(cat_name) values('$cat')";
	$run = mysqli_query($con,$query) or die(mysqli_error($con));
	if($run)
	{
		echo "category added";
	}

}

 ?>

<form method="post" action="">
	<label>Category</label><br>
		<input type="text" name="cat" placeholder="Enter category"><br><br>
		<input type="submit" name="sub">
</form>