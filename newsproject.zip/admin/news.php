<?php 
require("connection.php");

$query = "select * from news";
$run = mysqli_query($con,$query) or die(mysqli_error($con));
if($run)
{
	?>
	<a href="home.php?page=addnews"><span class="btn btn-primary">Add news</span></a><br>
	<table border="2" style="border-collapse: collapse;" width="100%">
		<tr>
			<th>Title</th>
			<th>Image</th>
			<th>News</th>
			<th colspan="2">Action</th>
		</tr>
	<?php
	while($data=mysqli_fetch_assoc($run))
	{
		?>
		<tr>
			<td><?= $data['title'];?></td>
			<td><img src="assets/images/<?= $data['image'];?>" width="200"></td>
			<td><?= substr($data['news'],0,15);?>...</td>
			<td><a href="home.php?page=editnews&&id=<?= $data['id'];?>">Edit</a></td>
			<td><a href="deletenews.php?id=<?= $data['id'];?>&&image=<?= $data['image'];?>">Delete</a></td>
		</tr>
		<?php
	}
	?>
	</table>
	<?php
}


 ?>