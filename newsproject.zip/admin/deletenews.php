<?php 
require("connection.php");
if(isset($_GET['id']))
{
	$id = $_GET['id'];
	$image = $_GET['image'];
	$query = "delete from news where id = '$id'";
	$run = mysqli_query($con,$query) or die(mysqli_error($con));
	if($run)
	{
		unlink('assets/images/'.$image);
		header("location:home.php?page=news");
	}
}


 ?>